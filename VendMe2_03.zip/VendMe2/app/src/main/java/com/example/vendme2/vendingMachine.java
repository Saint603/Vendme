package com.example.vendme2;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

public class vendingMachine extends AppCompatActivity {

    int total = 0;
/*
    CheckBox ckItem1 = findViewById(R.id.ckItem1);
    CheckBox ckItem2 = findViewById(R.id.ckItem2);
    CheckBox ckItem3 = findViewById(R.id.ckItem3);
    CheckBox ckItem5 = findViewById(R.id.ckItem5);
    CheckBox ckItem6 = findViewById(R.id.ckItem6);
    CheckBox ckItem7 = findViewById(R.id.ckItem7);
    CheckBox ckItem8 = findViewById(R.id.ckItem8);
    CheckBox ckItem9 = findViewById(R.id.ckItem9);
    TextView textView4 = findViewById(R.id.textView4);
*/
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vendingmachineslected);

        Button btnReturntoMap = (Button)findViewById(R.id.btnReturntoMap);
        Button btnCheckOut = (Button)findViewById(R.id.btnCheckOut);
        Button btnMainMenu = (Button)findViewById(R.id.mainMenuButton);


        btnReturntoMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startIntent = new Intent(getApplicationContext(), MapsActivity.class);
                startActivity(startIntent);
            }
        });

        btnCheckOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startIntent = new Intent(getApplicationContext(), paymentInformation.class);
                startActivity(startIntent);
            }
        });

        btnMainMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startIntent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(startIntent);
            }
        });

    }
    /*
    public void selectItems(View view){
        switch (view.getId()){
            case R.id.ckItem1:
                if (ckItem1.isChecked()){
                    total += 1;
                }
                break;
            case R.id.ckItem2:
                if (ckItem2.isChecked()){
                    total += 1;
                }
                break;
            case R.id.ckItem3:
                if (ckItem3.isChecked()){
                    total += 1;
                }
                break;
            case R.id.ckItem5:
                if (ckItem5.isChecked()){
                    total += 1;
                }
                break;
            case R.id.ckItem6:
                if (ckItem6.isChecked()){
                    total += 1;
                }
                break;
            case R.id.ckItem7:
                if (ckItem7.isChecked()){
                    total += 1;
                }
                break;
            case R.id.ckItem8:
                if (ckItem8.isChecked()){
                    total += 1;
                }
                break;
            case R.id.ckItem9:
                if (ckItem9.isChecked()) {
                    total += 1;
                }
                break;

        }
        textView4.setText(total);
    }
*/

}
